/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package swingserver;

import java.sql.*;

public class SwingServer {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {

        try {
            
            
            System.out.println("done");
        } catch (Exception e) {
            System.out.println(e);
        }

    }
}
